

from dotenv import load_dotenv
import os

def load_config():
    load_dotenv()
    return type("Config", (), {
        "BOT_TOKEN": os.getenv("BOT_TOKEN").strip(),
        "ADMIN_IDS": list(map(int, os.getenv("ADMIN_IDS").strip().split(","))),
        "CHANNEL_ID": int(os.getenv("CHANNEL_ID").strip()),
        "CHANNEL_LINK": os.getenv("CHANNEL_LINK").strip()
    })()
