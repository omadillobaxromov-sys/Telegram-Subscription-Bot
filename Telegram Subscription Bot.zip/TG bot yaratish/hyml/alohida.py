# flower_stable_diffusion.py
# O'rnatish (bash): 
#   pip install diffusers transformers accelerate safetensors
# Agar CUDA mavjud bo'lsa: pip install accelerate --upgrade
#
# Keyin, terminalda export HUGGINGFACE_TOKEN="your_token_here"
# yoki Windows: set HUGGINGFACE_TOKEN=your_token_here

import os
from diffusers import StableDiffusionPipeline
import torch

def generate_flower(prompt="A vibrant stylized flower, high detail, studio lighting, digital art", 
                    out_path="/mnt/data/flower_sd.png",
                    guidance_scale=7.5,
                    num_inference_steps=30,
                    device=None,
                    model_id="runwayml/stable-diffusion-v1-5"):
    # device selection
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    token = os.environ.get("HUGGINGFACE_TOKEN")
    if not token:
        raise RuntimeError("Please set HUGGINGFACE_TOKEN environment variable with your Hugging Face access token.")

    # load pipeline
    pipe = StableDiffusionPipeline.from_pretrained(model_id, use_auth_token=token)
    # enable half precision if GPU available
    if device == "cuda":
        pipe = pipe.to(device)
        pipe.enable_model_cpu_offload()
    else:
        pipe = pipe.to(device)

    # generate
    with torch.autocast(device if device!="cpu" else "cpu"):
        image = pipe(prompt, guidance_scale=guidance_scale, num_inference_steps=num_inference_steps).images[0]

    image.save(out_path)
    print("Saved AI-generated flower to:", out_path)

if __name__ == "__main__":
    # o'zgaruvchilarni xohlagancha o'zgartiring:
    prompt = "A colorful, highly detailed stylized flower, cinematic lighting, digital painting, ultra-detailed"
    generate_flower(prompt=prompt)
