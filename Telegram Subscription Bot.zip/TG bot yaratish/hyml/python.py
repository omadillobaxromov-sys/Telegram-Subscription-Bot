"""
Infinite Starfield - Tkinter
Run: python infinite_starfield.py

Simple, dependency-free "infinite" animation:
- Stars spawn continuously and move downwards.
- Use Up/Down arrows to increase/decrease speed.
- Space to pause/unpause, Esc to quit.
"""

import tkinter as tk
import random
import time

# Configuration
WIDTH, HEIGHT = 900, 600
FPS = 60
INITIAL_SPEED = 2.0
SPAWN_RATE = 0.12  # chance to spawn a star each frame (0..1)
MAX_STARS = 400

class Star:
    def __init__(self, x, y, size, speed, color):
        self.x = x
        self.y = y
        self.size = size
        self.speed = speed
        self.color = color

    def step(self):
        self.y += self.speed

class StarFieldApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Infinite Starfield")
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="#001327", highlightthickness=0)
        self.canvas.pack()

        self.stars = []
        self.speed_multiplier = INITIAL_SPEED
        self.paused = False
        self.last_time = time.time()

        # UI text
        self.info = self.canvas.create_text(10, 10, anchor="nw", fill="#bfefff",
                                            font=("Arial", 12),
                                            text=self._info_text())

        # Bind keys
        root.bind("<Up>", lambda e: self.change_speed(1.12))
        root.bind("<Down>", lambda e: self.change_speed(0.88))
        root.bind("<space>", lambda e: self.toggle_pause())
        root.bind("<Escape>", lambda e: root.quit())

        # Start main loop
        self.running = True
        self._loop()

    def _info_text(self):
        return f"Stars: {len(self.stars)}  Speed: {self.speed_multiplier:.2f}  (Up/Down change, Space pause, Esc quit)"

    def change_speed(self, factor):
        self.speed_multiplier *= factor
        if self.speed_multiplier < 0.2:
            self.speed_multiplier = 0.2
        if self.speed_multiplier > 12:
            self.speed_multiplier = 12

    def toggle_pause(self):
        self.paused = not self.paused

    def spawn_star(self):
        # spawn at random x, slightly above the top
        x = random.uniform(0, WIDTH)
        y = random.uniform(-40, -5)
        # size and base speed vary; speed scales with global multiplier
        size = random.choice([1, 1, 1, 2, 2, 3])  # bias to small stars
        base_speed = random.uniform(0.6, 2.2)
        speed = base_speed * self.speed_multiplier
        # color variation (soft)
        gray = random.randint(180, 255)
        color = f"#{gray:02x}{gray:02x}{(gray+20 if gray+20<256 else 255):02x}"
        return Star(x, y, size, speed, color)

    def _loop(self):
        # time control for approx FPS
        now = time.time()
        dt = now - self.last_time
        self.last_time = now

        if not self.paused:
            # maybe spawn a few stars (probabilistic)
            if len(self.stars) < MAX_STARS and random.random() < SPAWN_RATE:
                self.stars.append(self.spawn_star())

            # update stars
            for s in self.stars:
                # update speed to reflect current multiplier (so when you change speed existing stars accelerate too)
                s.speed = max(0.1, (s.speed / max(1.0, self.speed_multiplier)) * self.speed_multiplier)  # keep relative
                s.step()

            # remove stars that passed bottom (recycle for "infinite" effect)
            new_stars = []
            for s in self.stars:
                if s.y - s.size < HEIGHT + 30:
                    new_stars.append(s)
                else:
                    # optionally respawn at top to keep count stable
                    if random.random() < 0.6:
                        ns = self.spawn_star()
                        new_stars.append(ns)
            self.stars = new_stars

        # draw
        self.canvas.delete("star")  # remove previous stars (tagged)
        for s in self.stars:
            x1 = s.x - s.size
            y1 = s.y - s.size
            x2 = s.x + s.size
            y2 = s.y + s.size
            if s.size <= 1:
                # draw a single pixel as tiny oval
                self.canvas.create_rectangle(x1, y1, x2, y2, fill=s.color, outline=s.color, tag="star")
            else:
                # small oval for larger stars
                self.canvas.create_oval(x1, y1, x2, y2, fill=s.color, outline="", tag="star")
            # simple twinkle: slight alpha simulated by color change (light)
            if random.random() < 0.02:
                self.canvas.create_oval(s.x-0.5, s.y-0.5, s.x+0.5, s.y+0.5, fill="#ffffff", outline="", tag="star")

        # update UI text
        self.canvas.itemconfigure(self.info, text=self._info_text())

        # schedule next frame
        if self.running:
            self.root.after(int(1000 / FPS), self._loop)

if __name__ == "__main__":
    root = tk.Tk()
    app = StarFieldApp(root)
    root.mainloop()
