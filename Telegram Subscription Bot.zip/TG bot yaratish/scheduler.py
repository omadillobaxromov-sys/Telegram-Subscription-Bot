
import asyncio
from datetime import datetime
from aiogram import Bot
from database import get_all_users, mark_invalid
from config import load_config

config = load_config()
CHANNEL_ID = config.CHANNEL_ID

async def check_subscriptions(bot: Bot):
    users = await get_all_users()
    now = datetime.utcnow()

    for user in users:
        if user['expires_at'] and datetime.fromisoformat(user['expires_at']) < now:
            try:
                await bot.ban_chat_member(chat_id=CHANNEL_ID, user_id=user['user_id'], until_date=0)
                await bot.unban_chat_member(chat_id=CHANNEL_ID, user_id=user['user_id'])
                await mark_invalid(user['user_id'])
                print(f"⏳ Obuna muddati tugadi va {user['user_id']} chiqarildi.")
            except Exception as e:
                print(f"⚠️ {user['user_id']} ni chiqarishda xato: {e}")

async def scheduler_task(bot: Bot):
    while True:
        try:
            await check_subscriptions(bot)
        except Exception as e:
            print(f"⚠️ Jadval tekshiruvda xatolik: {e}")
        await asyncio.sleep(3600)  # 1 soatda 1 marta

def setup_scheduler(bot: Bot):
    asyncio.create_task(scheduler_task(bot))
